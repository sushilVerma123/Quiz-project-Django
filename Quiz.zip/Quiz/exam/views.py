from django.forms import formset_factory
from django.shortcuts import render, redirect
from .models import Question, UserSubmission
from .forms import SubmissionForm
import random


def start_quiz(request):
    # Start a new quiz session by clearing previous submissions
    UserSubmission.objects.all().delete()
    # return redirect('quiz_question')

    return render(request, 'start_quiz.html')


def quiz_question(request):
    # Get all questions in order
    questions = Question.objects.all()

    # Initialize the session index if not already set
    if 'current_index' not in request.session:
        request.session['current_index'] = 0

    # Fetch the current question based on the index
    current_index = request.session['current_index']
    if current_index >= len(questions):
        # If all questions are answered, reset the session and redirect to summary
        del request.session['current_index']
        return redirect('quiz_summary')

    question = questions[current_index]
    form = SubmissionForm(question)

    if request.method == 'POST':
        form = SubmissionForm(question, request.POST)
        if form.is_valid():
            selected_option = form.cleaned_data['selected_option']
            is_correct = (selected_option == question.correct_option)
            UserSubmission.objects.create(
                question=question,
                selected_option=selected_option,
                is_correct=is_correct
            )

            # Move to the next question
            request.session['current_index'] += 1
            return redirect('quiz_question')

    context = {'question': question, 'form': form}
    return render(request, 'quiz_question.html', context)
def quiz_summary(request):
    submissions = UserSubmission.objects.all()
    total = submissions.count()
    correct = submissions.filter(is_correct=True).count()
    incorrect = total - correct

    context = {
        'submissions': submissions,
        'total': total,
        'correct': correct,
        'incorrect': incorrect
    }
    return render(request, 'quiz_summary.html', context)